package com.corecmp.shared.db

import app.cash.sqldelight.Transacter
import app.cash.sqldelight.db.QueryResult
import app.cash.sqldelight.db.SqlDriver
import app.cash.sqldelight.db.SqlSchema
import com.aj.shared.db.DatabaseQueries
import com.corecmp.shared.db.shared.newInstance
import com.corecmp.shared.db.shared.schema
import kotlin.Unit

public interface CoreCmpDatabase : Transacter {
  public val databaseQueries: DatabaseQueries

  public companion object {
    public val Schema: SqlSchema<QueryResult.Value<Unit>>
      get() = CoreCmpDatabase::class.schema

    public operator fun invoke(driver: SqlDriver): CoreCmpDatabase =
        CoreCmpDatabase::class.newInstance(driver)
  }
}
